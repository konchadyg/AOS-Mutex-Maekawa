//========================================================
//|     CS6378 - PROJECT 2                               |
//|     Member 1: Piyush Makani [PXM140430]              |
//|     Member 2: Konchady Gaurav Shenoy [KXS168430]     |
//|     Instructor: Dr. Neeraj Mittal                    |
//|     Oct 2016                                         |
//|     The University of Texas at Dallas                |
//========================================================

public class NodeLocation {
	String serverName;
	int portNumber;
	public NodeLocation(String serverName, int portNumber)
	{
		this.serverName = serverName;
		this.portNumber = portNumber;
	}
}
